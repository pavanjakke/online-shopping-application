package com.zensar.bean;

public enum OrderStatus {
	BOOKED,SHIPPED,DELIVERED,DELAYED,CLOSED
}
