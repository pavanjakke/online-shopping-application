import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deleteproducts',
  templateUrl: './deleteproducts.component.html',
  styleUrls: ['./deleteproducts.component.css']
})
export class DeleteproductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
