export interface IProducts{
    productId : number;
	productName : string;
	price : number;
	color : string;
	dimensions : string;
	specification : string;
	manufacturer : string;
	quantity : number;
    categoryId : string;
   }