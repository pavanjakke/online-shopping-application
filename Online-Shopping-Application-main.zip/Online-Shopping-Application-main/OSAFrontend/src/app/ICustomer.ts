export interface ICustomer{
    customerId:number,
    firstName:string,
    lastName:string,
    mobileNumber:string,
    addressid:number,
    email:string
}