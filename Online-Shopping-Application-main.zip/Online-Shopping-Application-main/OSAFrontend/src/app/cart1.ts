
export interface ICart{
    cartId:number;
   ICustomer : any;
   IProducts : any;
   quantity:number;
   }