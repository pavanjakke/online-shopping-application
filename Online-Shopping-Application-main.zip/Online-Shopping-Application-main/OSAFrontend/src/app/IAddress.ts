export interface IAddress{
    addressId:number,
    streetNo:string,
    buildingName:string,
    city:string,
    state:string
    country:string,
    pincode:string

}